#include "XnSyncSocketConnection.h"

namespace xn
{

class ClientSyncSocketConnection : public SyncSocketConnection
{

};

}
